from flask import Flask, render_template, request, redirect, url_for
import cv2
import pytesseract
from werkzeug.utils import secure_filename
import os

app = Flask(__name__)

# Set up directory for uploaded files
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Allowed file extensions
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'mp4', 'avi'}

# Function to check if the file is allowed
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Route for the home page
@app.route('/')
def home():
    return render_template('index.html')

# Route for the image upload page
@app.route('/image.html', methods=['GET', 'POST'])
def upload_image():
    if request.method == 'POST':
        # Get the uploaded file
        file = request.files['file']
        if file and allowed_file(file.filename):
            # Secure the filename and save it
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)

            # Process the image to detect number plate
            plate_number = detect_plate(filepath)

            # Pass the plate number to the result page
            return render_template('result.html', plate_number=plate_number)
    return render_template('image.html')

# Route for the video upload page
@app.route('/video.html', methods=['GET', 'POST'])
def upload_video():
    if request.method == 'POST':
        # Get the uploaded video file
        file = request.files['file']
        if file and allowed_file(file.filename):
            # Save the video file
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)

            # Process the video to detect number plates (Video processing logic)
            plate_number = detect_video(filepath)

            # Pass the plate number to the result page
            return render_template('result.html', plate_number=plate_number)
    return render_template('video.html')

# Route for live camera feed (optional)
@app.route('/camera.html', methods=['GET'])
def camera():
    return render_template('camera.html')

# Function to detect the car number plate in the image
def detect_plate(image_path):
    # Use OpenCV to process the image and Tesseract to extract text
    image = cv2.imread(image_path)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Use pytesseract to extract text from the image directly
    text = pytesseract.image_to_string(gray, config='--psm 8')  # Using PSM 8 for single word or line

    # Here, you can add further processing to clean up and validate the detected text
    return text.strip()

# Function to process video and detect the number plate
def detect_video(video_path):
    # Open the video using OpenCV
    cap = cv2.VideoCapture(video_path)
    plate_number = "No Plate Detected"
    
    # Loop through the video frames
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        
        # Convert frame to grayscale for plate detection
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Use pytesseract to extract text from the current frame
        text = pytesseract.image_to_string(gray, config='--psm 8')
        
        if text.strip():  # If text is found, break out of the loop
            plate_number = text.strip()
            break

    cap.release()
    return plate_number

if __name__ == '__main__':
    app.run(debug=True)
